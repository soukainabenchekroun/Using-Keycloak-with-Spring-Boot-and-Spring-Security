package com.soukainabenchekroun.keycloakspringsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloakSpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeycloakSpringSecurityApplication.class, args);
	}

}
