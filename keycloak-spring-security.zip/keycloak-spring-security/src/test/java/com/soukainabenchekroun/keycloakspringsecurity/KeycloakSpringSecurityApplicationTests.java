package com.soukainabenchekroun.keycloakspringsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloakSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
